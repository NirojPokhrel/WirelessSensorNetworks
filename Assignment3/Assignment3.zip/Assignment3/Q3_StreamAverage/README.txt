README for Q3
Author Group 5

Description:

Average for the 10 samples is calculated using the stream and is displayed.