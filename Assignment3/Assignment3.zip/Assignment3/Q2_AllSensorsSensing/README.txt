README for Q2
Author Group 5

Description:

Read the sensor data from the shell command for all the sensors and display it.