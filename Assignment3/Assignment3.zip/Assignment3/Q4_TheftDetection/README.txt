README for Q3
Author Group 5

Description:

If the light sensor value is less than threshold then all the leds are turned on. The threshold value is chaned from the command line using 
$set [value]
