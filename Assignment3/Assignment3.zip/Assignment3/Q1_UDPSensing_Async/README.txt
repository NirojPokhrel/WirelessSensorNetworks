README for Q1 
Author Group 5

Description:

Read the sensor data from the shell command line. After the shell command is issued and the control arrives at eval function then the sensor is prompted to read the sensor data and readDone is received using the write command the sensor value is written back to the shell.