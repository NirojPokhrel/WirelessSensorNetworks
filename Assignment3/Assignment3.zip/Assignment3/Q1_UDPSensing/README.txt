README for Q1 
Author Group 5

Description:

Read the sensor data from the shell command line. Here, the timer keeps on running and sampling the sensors data all the time and keeps on storing the latest value which is displayed in the shell command.