README for BlinkWithGpio

Description:

The blink app is modified and instead of using Leds components General IO is used directly.