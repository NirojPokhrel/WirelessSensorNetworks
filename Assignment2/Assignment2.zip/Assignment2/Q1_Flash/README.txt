README for FlashBlink
Author Group 5

Description:

Led0 turns on for 100ms and turns off for 1000 ms continuosly.