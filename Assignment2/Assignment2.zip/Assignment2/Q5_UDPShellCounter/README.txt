README for FlashBlink
Author Group 5

Description:

Give command in the shell. $count [0-7] 
$count 7 ( all three leds are turned on)