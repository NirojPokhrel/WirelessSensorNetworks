README for BinaryCounter

Description:
Binary Counter for counting from 0 to 7 and repeat it for four times.