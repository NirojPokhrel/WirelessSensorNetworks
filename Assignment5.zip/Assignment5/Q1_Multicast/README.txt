README for Q1
Author Group 5

Description:
Changed the messaging to send the data locally as well by including locally in the command.